import {book} from '../../app/book';
//data are all stored here
export const BOOKDATA:book[]=[    
    
            {  author:"Kishimoto", bookName:"Naruto", genre:"Action-comedy-fantasy", year:2002, picture:"assets/Images/naruto.jpg"},

            {  author:"Rudyard Kipling", bookName:"Jungle Book", genre:"fantasy", year:1992, picture:"assets/Images/JungleBook.jpg"},

            {  author:"Mark Twain", bookName:"Adventures of Tom Sawyer", genre:"Fantasy-comedy", year:2003, picture:"assets/Images/ATS.jpg"},

            {  author:"Toriyama", bookName:"One Punch Man", genre:"Action-comedy-parody", year:2008, picture:"assets/Images/OPM.jpg"}

      

    ];
