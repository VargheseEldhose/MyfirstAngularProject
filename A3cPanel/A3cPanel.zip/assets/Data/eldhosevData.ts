import { eldhosev } from '../../app/eldhosev';
export const DETAILS: eldhosev[]= [
{
studentID:991588959,
studentName:"Varghese Eldhose",
loginName:"eldhosev",
campus:"Davis",
assignmentTitle:"eldhosevA3"

}
];
